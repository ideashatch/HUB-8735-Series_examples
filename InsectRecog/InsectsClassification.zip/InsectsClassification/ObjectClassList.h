#ifndef __OBJECTCLASSLIST_H__
#define __OBJECTCLASSLIST_H__

struct ObjectDetectionItem {
    uint8_t index;
    const char* objectName;
    uint8_t filter;
};

// List of objects the pre-trained model is capable of recognizing
// Index number is fixed and hard-coded from training
// Set the filter value to 0 to ignore any recognized objects
ObjectDetectionItem itemList[5] = {
    {0,  "Cerambycidae",         1},
    {1,  "Coccinellidae",        1},
    {2,  "Hydrophilidae",            1},
    {3,  "Lucanidae",      1},
    {4,  "Pentatomidae",      1},
};

#endif
